"""
mission_manager_node.py
=============================================================
ROS 2 Node: Mission-Manager (Half-Plane Gate Switching)

Subscriptions:
  /objects         (geometry_msgs/PoseArray)  -- bestaetigte Tracks
  /state/filtered  (nav_msgs/Odometry)         -- gefilterte Boot-Position

Publications:
  /mission/target_gate  (std_msgs/Int32)   -- aktuell anzufahrendes Tor
  /mission/status       (std_msgs/String)  -- "RUNNING" | "COMPLETED"

Takt: callback-getrieben
"""

import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseArray
from nav_msgs.msg import Odometry
from std_msgs.msg import Int32, String

from boot_control.mission_manager_algorithm import MissionManager
from boot_control.course_manager_algorithm import CourseManager, Buoy


class MissionManagerNode(Node):
    def __init__(self):
        super().__init__('mission_manager_node')

        self.declare_parameter('acceptance_radius', 4.0)  # m, Tor-Annahmeradius

        acc_r = self.get_parameter('acceptance_radius').value

        self._manager = MissionManager(acceptance_radius=acc_r)
        self._course  = CourseManager()   # fuer Torzentren

        self._boat_pos = np.zeros(2)
        self._gate_centers: np.ndarray = np.empty((0, 2))

        self.create_subscription(PoseArray, '/objects',        self._objects_cb, 10)
        self.create_subscription(Odometry,  '/state/filtered', self._state_cb,   10)

        self._pub_gate   = self.create_publisher(Int32,  '/mission/target_gate', 10)
        self._pub_status = self.create_publisher(String, '/mission/status',       10)

        self.get_logger().info('mission_manager_node gestartet.')

    # ------------------------------------------------------------------
    def _objects_cb(self, msg: PoseArray):
        buoys = []
        for pose in msg.poses:
            color = 'red' if pose.orientation.w > 0 else 'green'
            buoys.append(Buoy(x=pose.position.x, y=pose.position.y, color=color))
        self._course.update_objects(buoys)
        self._gate_centers = self._course.calculate_gate_centers()
        self._check_and_publish()

    # ------------------------------------------------------------------
    def _state_cb(self, msg: Odometry):
        self._boat_pos = np.array([
            msg.pose.pose.position.x,
            msg.pose.pose.position.y,
        ])
        self._check_and_publish()

    # ------------------------------------------------------------------
    def _check_and_publish(self):
        if len(self._gate_centers) > 0 and not self._manager.mission_completed:
            self._manager.check_gate_passage(self._boat_pos, self._gate_centers)

        gate_msg = Int32()
        gate_msg.data = self._manager.current_gate
        self._pub_gate.publish(gate_msg)

        status_msg = String()
        status_msg.data = 'COMPLETED' if self._manager.mission_completed else 'RUNNING'
        self._pub_status.publish(status_msg)


def main(args=None):
    rclpy.init(args=args)
    node = MissionManagerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
