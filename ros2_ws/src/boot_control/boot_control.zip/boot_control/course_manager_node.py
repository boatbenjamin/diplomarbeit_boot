"""
course_manager_node.py
=============================================================
ROS 2 Node: Pfadplanung (B-Spline durch Torzentren)

Subscriptions:
  /objects              (geometry_msgs/PoseArray)  -- bestätigte Tracks aus object_tracker_node
  /mission/target_gate  (std_msgs/Int32)            -- aktuell anzufahrendes Tor (Index)

Publications:
  /path  (nav_msgs/Path)
    B-Spline-Pfad durch alle noch offenen Tore inkl. 15m Anlaufbahn.
    Jede PoseStamped.pose.position.x/y = Pfadpunkt in Weltkoordinaten.

Takt: callback-getrieben (beim Eingang neuer /objects oder /mission/target_gate)
Bojen-Farbkodierung aus /objects:
  orientation.w = 1.0  -> rot  (Backbord)
  orientation.w = -1.0 -> gruen (Steuerbord)
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseArray, PoseStamped
from nav_msgs.msg import Path
from std_msgs.msg import Int32

from boot_control.course_manager_algorithm import CourseManager, Buoy


class CourseManagerNode(Node):
    def __init__(self):
        super().__init__('course_manager_node')

        self.declare_parameter('num_path_points', 200)      # Aufloesung des Splines
        self.declare_parameter('backward_extension', 15.0)  # m, Anlaufbahn

        self._num_pts = self.get_parameter('num_path_points').value
        self._bwd_ext = self.get_parameter('backward_extension').value

        self._manager = CourseManager()
        self._target_gate = 0

        self.create_subscription(PoseArray, '/objects', self._objects_cb, 10)
        self.create_subscription(Int32, '/mission/target_gate', self._gate_cb, 10)

        self._pub = self.create_publisher(Path, '/path', 10)

        self.get_logger().info('course_manager_node gestartet.')

    # ------------------------------------------------------------------
    def _gate_cb(self, msg: Int32):
        self._target_gate = msg.data
        self._manager.update_mission(self._target_gate)
        self._compute_and_publish()

    # ------------------------------------------------------------------
    def _objects_cb(self, msg: PoseArray):
        buoys = []
        for pose in msg.poses:
            color = 'red' if pose.orientation.w > 0 else 'green'
            buoys.append(Buoy(
                x=pose.position.x,
                y=pose.position.y,
                color=color,
            ))
        self._manager.update_objects(buoys)
        self._compute_and_publish()

    # ------------------------------------------------------------------
    def _compute_and_publish(self):
        path_x, path_y = self._manager.compute_smoothed_path(
            num_points=self._num_pts,
            backward_extension=self._bwd_ext,
        )

        if len(path_x) == 0:
            self.get_logger().warn('Kein Pfad berechnet (zu wenig Bojen?).')
            return

        path_msg = Path()
        path_msg.header.stamp = self.get_clock().now().to_msg()
        path_msg.header.frame_id = 'odom'

        for x, y in zip(path_x, path_y):
            ps = PoseStamped()
            ps.header = path_msg.header
            ps.pose.position.x = float(x)
            ps.pose.position.y = float(y)
            ps.pose.orientation.w = 1.0
            path_msg.poses.append(ps)

        self._pub.publish(path_msg)


def main(args=None):
    rclpy.init(args=args)
    node = CourseManagerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
